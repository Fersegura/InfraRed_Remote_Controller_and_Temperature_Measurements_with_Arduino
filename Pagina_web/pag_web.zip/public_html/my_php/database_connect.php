<?php

// DESCOMENTAR PARA USAR LA BD LOCAL (XAMPP) 
// $con=mysqli_connect("localhost","root","","id15900605_esp8266");// server, user, password, database

?>